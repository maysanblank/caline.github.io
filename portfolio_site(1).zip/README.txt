Petunjuk:
- Buka index.html di browser untuk melihat situs.
- Situs ini menggunakan Tailwind (CDN) dan AOS (Animate On Scroll) via CDN; koneksi internet diperlukan untuk library CDN.
- Ubah teks di file HTML untuk menyesuaikan konten (nama, link laporan, dsb).
- Jika mau, saya bisa bantu: menambahkan modal detail project, form kontak, atau build React versi.
